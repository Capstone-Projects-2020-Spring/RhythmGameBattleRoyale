﻿using System.Collections;
using UnityEngine;
using System.IO;
using System.Diagnostics;
using System;
using System.Collections.Generic;
using UnityEngine.Networking;

public class AudioLoader : MonoBehaviour
{
    AudioSource audioSource;

    //pass in the downloaded file name for the song name 
    string songName = "Song.mp3";
    string filePath = @"C:/MAC/Users/bolaji/Downloads/Song.mp3";



    void Start()
    {
        StartCoroutine(GetAudioClip());
        GetMetadata(filePath);
    }

    IEnumerator GetAudioClip()
    {
        using (UnityWebRequest request = UnityWebRequestMultimedia.GetAudioClip(Path.Combine("file://" + Application.streamingAssetsPath, songName), AudioType.MPEG))
        {
            yield return request;

            if (request.isNetworkError)
            {
                UnityEngine.Debug.Log(request.error);
            }
            else
            {
                AudioClip myClip = DownloadHandlerAudioClip.GetContent(request);
            }
        }

    }

    //saving the metadata from the file 

    private void GetMetadata(string filePath)
    {
        byte[] b = new byte[128];

        string Title = "";

        string Artist = "";

        string Album = "";

        string Year = "";

        FileStream fileStream = new FileStream(filePath, FileMode.Open);

        fileStream.Seek(-128, SeekOrigin.End);

        fileStream.Read(b, 0, 128);

        bool TAG = false;

        string checkIfTag = System.Text.Encoding.Default.GetString(b, 0, 3);

        if (checkIfTag.CompareTo("TAG") == 0)
        {
            Console.WriteLine("Tag   is   setted! ");
            TAG = true;
        }

        if (TAG)
        {
            //get   title   of   song; 
            Title = System.Text.Encoding.Default.GetString(b, 3, 30);
            Console.WriteLine("Title: " + Title);
            //get   singer; 
            Artist = System.Text.Encoding.Default.GetString(b, 33, 30);
            Console.WriteLine("Singer: " + Artist);
            //get   album; 
            Album = System.Text.Encoding.Default.GetString(b, 63, 30);
            Console.WriteLine("Album: " + Album);

            //get   Year   of   publish; 
            Year = System.Text.Encoding.Default.GetString(b, 93, 4);

            Console.WriteLine("Year: " + Year);
        }

        List<string> meta = new List<string>
        {
            Title,
            Artist,
            Album,
            Year
        };


    }


}